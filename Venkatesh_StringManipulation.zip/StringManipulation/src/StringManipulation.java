
public class StringManipulation {
	
	public static void main(String[] args) {
	
	String firstNameString= new String ("Venkatesh");
	StringBuffer firstNameBuffer= new StringBuffer ("Venkatesh");
	StringBuilder firstNameBuilder= new StringBuilder ("Venkatesh");
	
	System.out.println("Hi Doing the String Manipulation");
	
	long start = System.currentTimeMillis();
	long end=0;
	long runTime=0;
	int i=0;
	
	
		while(i < 1000000) {
			firstNameString.concat("hi");
			i++;
		}
	//System.out.println("String is " +firstNameString);
	end = System.currentTimeMillis();
	runTime= end - start;
	System.out.println("To concat String Time taken is " +runTime);
	
	end=0;
	start=0;
	runTime=0;
	i=0;
	
	start=System.currentTimeMillis();
	
		while(i < 1000000) {
			firstNameBuffer.append("hi");
			i++;	
		}
		
	end = System.currentTimeMillis();
	runTime= end - start;
	System.out.println("To concat StringBuffer Time taken is " +runTime);
	end=0;
	start=0;
	runTime=0;
	i=0;
	
	start=System.currentTimeMillis();
	
		while(i < 1000000) {
			firstNameBuilder.append("hi");
			i++;
		}
	
	end = System.currentTimeMillis();
	runTime= end - start;
	System.out.println("To concat StringBuilder Time taken is " +runTime);	

}
}