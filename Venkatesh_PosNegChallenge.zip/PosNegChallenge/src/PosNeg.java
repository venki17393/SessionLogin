/*
 * Venkatesh K
 * 07-April-2017
 * posNeg Challenge
 */


import static java.lang.System.out;
import java.util.Scanner;

public class PosNeg {
	
	/**
	 * Given 2 int values, return true if one is negative and one is positive.
	 * Except if the parameter "negative" is true, then return true only if both
	 * are negative.
	 * 
	 * @param a
	 * @param b
	 * @param negative
	 * @return
	 */

	public static boolean posNeg(int a, int b, boolean negative ) {
		//Conditions when negative is false 
		if (negative == false) {
				if ((a<0 || b<0 ) && (a>0 || b>0)) {
					
					return true;
				}
				else {
					return false;
				}
		}
		else {
				if (a<0 && b<0) {
					return true;
				}
				return false;
		}
	}
	
	// Main method 
	public static void main (String args[]) {
		int a, b;
		boolean negative;
		Scanner sc = new Scanner (System.in);
		
		// The value of NONZERO a & b to be entered by user
		out.println("Enter the NONZERO value of  a & b");
		a=sc.nextInt();
		b=sc.nextInt();
		
		// The value of Negative to be entered by user
		out.println("Enter your value of negative");
		negative=sc.nextBoolean();
		
		//Calling the posNeg() and storing the result in result variable
		boolean result = PosNeg.posNeg(a,b,negative);
		out.println("When a is " +a+ " b is " +b+ " and neagtive is " +negative+ " Result is ==" +result);
		
		
	}
}
