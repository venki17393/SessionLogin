
import java.util.*;

public class Number {

	private String number;
	private String type;
	private Map<String, String> numberMap = new HashMap<String, String>();

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public String gettype() {
		return type;
	}

	public void settype(String type) {
		this.type = type;
	}

	public Map<String, String> getnumberMap() {
		return numberMap;
	}

	public void setnumberMap(Map<String, String> numberMap) {
		this.numberMap = numberMap;
	}
}
