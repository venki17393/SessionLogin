import java.util.Map;

public class Contact {

	Name name = new Name();
	Number number = new Number();
	Email email = new Email();
	Address address = new Address();

	// THIS IS FOR NAMES CLASS

	public String getFirstName() {
		return name.getFirstName();
	}

	public void setFirstName(String firstName) {
		name.setFirstName(firstName);
	}

	public String getLastName() {
		return name.getLastName();
	}

	public void setLastName(String lastName) {
		name.setLastName(lastName);
	}

	public String getNickName() {
		return name.getNickName();
	}

	public void setNickName(String nickName) {
		name.setNickName(nickName);
	}

	public String getFamilyName() {
		return name.getFamilyName();
	}

	public void setFamilyName(String familyName) {
		name.setFamilyName(familyName);
	}

	// THIS IS FOR NUMBER CLASS
	public String getNumber() {
		return number.getNumber();
	}

	public void setNumber(String phoneNumber) {
		number.setNumber(phoneNumber);
	}

	public String getNumbertype() {
		return number.gettype();
	}

	public void setNumbertype(String type) {
		number.settype(type);
	}

	public Map<String, String> getnumberMap() {
		return number.getnumberMap();
	}

	public void setnumberMap(Map<String, String> numberMap) {
		number.setnumberMap(numberMap);
	}

	// THIS IS FOR EMAIL CLASS

	public String getEmail() {
		return email.getEmail();
	}

	public void setEmail(String mail) {
		email.setEmail(mail);
	}

	public String getEmailtype() {
		return email.gettype();
	}

	public void setEmailtype(String type) {
		email.settype(type);
	}

	public Map<String, String> getMapMail() {
		return email.getMapMail();
	}

	public void setMapMail(Map<String, String> mapMail) {
		email.setMapMail(mapMail);
	}

	// THIS IS FOR THE ADDRESS CLASS

	public String getAddress() {
		return address.getAddress();
	}

	public void setAddress(String useraddress) {
		address.setAddress(useraddress);
	}

	public String gettype() {
		return address.gettype();
	}

	public void setAddresstype(String type) {
		address.settype(type);
	}

	public Map<String, String> getAddressMap() {
		return address.getAddressMap();
	}

	public void setAddressMap(Map<String, String> addressMap) {
		address.getAddressMap();
	}

}
