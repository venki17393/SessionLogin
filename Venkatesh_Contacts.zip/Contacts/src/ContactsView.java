
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.io.*;

class ContactsView {

	Contact contact = new Contact();
	Scanner en = new Scanner(System.in);

	public void welcomeMessage() {
		System.out.println("Hi Welcome to the Contact Application!!!");
	}

	public void exitMessage() {
		System.out.println("Thank you for using our Contact Application");
	}

	public int getChoice() {
		int choice;
		System.out.println("1.Name 2.Number 3.Email 4.Address");
		choice = en.nextInt();
		return choice;
	}

	public String addOneMore() {
		System.out.println("Do you want to add another contact fileds ->  yes");
		String isValid = en.next();
		return isValid;
	}

	public void setName() {
		System.out.println("FirstName :");
		String firstName = en.next();
		System.out.println("LastName :");
		String lastName = en.next();
		System.out.println("NickName :");
		String nickName = en.next();
		System.out.println("FamilyName :");
		String familyName = en.next();
		contact.setFirstName(firstName);
		contact.setLastName(lastName);
		contact.setNickName(nickName);
		contact.setFamilyName(familyName);
	}

	public void setNumber() {

		String type;
		System.out.println("Enter the Mobile Number ");
		String phoneNumber = en.next();
		System.out.println("Give your choice for Type -> 1.Personal 2.Home 3.Office");
		int choice = en.nextInt();

		switch (choice) {
		case 1:
			type = "personal";
			break;
		case 2:
			type = "Home";
			break;
		case 3:
			type = "Office";
			break;
		default:
			type = "Custom";
			break;
		}

		Map<String, String> numberMap = new HashMap<String, String>();
		numberMap.put(type, phoneNumber);
		contact.setNumber(phoneNumber);
		contact.setNumbertype(type);
		contact.setnumberMap(numberMap);

	}

	public void setMail() {

		System.out.println("EMail ID: ");
		String mail = en.next();
		String type;

		System.out.println("Give your choice for Type -> 1.personal 2.General 3.Office");
		int choice = en.nextInt();

		switch (choice) {
		case 1:
			type = "personal";
			break;

		case 2:
			type = "General";
			break;
		case 3:
			type = "Office";
			break;
		default:
			type = "Custom";
			break;

		}

		contact.setEmail(mail);
		contact.setEmailtype(type);

	}

	public void setAddress() {

		String type = "";
		System.out.println("Address ID: ");
		String contactAddress = en.next();
		// en.next();
		System.out.println("Give your choice for Type -> 1.Home 2.Office");
		int choice = en.nextInt();
		switch (choice) {
		case 1:
			type = "personal";
			break;

		case 2:
			type = "Office";
			break;
		default:
			type = "Custom";
			break;
		}

		contact.setAddress(contactAddress);
		contact.setAddresstype(type);
		// contact.Map(numberMap);
	}
}
