
import java.util.Scanner;

class MainController {

	public static void main(String[] args) {
		Scanner en = new Scanner(System.in);
		String isValid = "";
		ContactsView contactView = new ContactsView();

		contactView.welcomeMessage();

		do {

			int choice = contactView.getChoice();
			switch (choice) {

			case 1:
				contactView.setName();
				break;

			case 2:
				contactView.setNumber();
				break;

			case 3:
				contactView.setMail();
				break;

			case 4:
				contactView.setAddress();
				break;

			default:
				System.out.println("Give correct Choice ");
			}

			isValid = contactView.addOneMore();
		} while (isValid.equals("yes"));
		contactView.exitMessage();
	}
}
