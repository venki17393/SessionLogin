import java.util.*;

class Email {

	private String email;
	private String type;
	private Map<String, String> mapMail = mapMail = new HashMap<String, String>();;

	// Getters And Setters for the above variables

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String gettype() {
		return type;
	}

	public void settype(String type) {
		this.type = type;
	}

	public Map<String, String> getMapMail() {
		return mapMail;
	}

	public void setMapMail(Map<String, String> mapMail) {
		this.mapMail = mapMail;
	}
}