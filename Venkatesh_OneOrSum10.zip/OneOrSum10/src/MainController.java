import java.util.Scanner;

public class MainController {
	public static void main(String args[]) {
		int a,b;
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the value of a PREFERABLY IN the range of 0 to 10");
		a=scan.nextInt();
		System.out.println("Enter the value of b PREFERABLY IN the range of 0 to 10");
		b=scan.nextInt();
		
		boolean result= OneOrSumTen.isOneOrSum10(a, b);//function call
		
		if(result){
			System.out.println("When A is " +a+ ", when B is " +b+ " the result is " +result);
		}
		else{
			System.out.println("FAIL!!");
		}	
		
	}
}
