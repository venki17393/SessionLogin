/*
 * Venkatesh K
 * 11-April-2017
 * isOneOrSum10 Challenge
 */

import java.util.*;

public class OneOrSumTen {
	public static boolean isOneOrSum10(int a, int b) {
		
		/**
		 * Given 2 int values, return true if one is equal to 10 or their sum is equal to 10. 
		 * @param a
		 * @param b
		 * @return boolean
		 */

		int sum=a+b;
		// Here we check the values of a, b and their sum
		if ((a==10) | (b==10) | (sum==10)) {
			return true; // Returns true if either of them is equal to 10
		}
		else {
			return false; // Returns false if none of them is equal to 10
		}
	}
	
		public static void main(String args[]) {
			int a,b;
			
			//Case 1 when a=9 and b=10, Result must be True
			a=9;
			b=10;
			boolean result= OneOrSumTen.isOneOrSum10(a, b);
			
			if(result){
				System.out.println("When A is " +a+ ", when B is " +b+ " the result is " +result+ " EXPECTED IS TRUE" );
			}
			else{
				System.out.println("FAIL!!");
			}	
			
			
			//Case 2 when a=9 and b=9, Result must be False
			a=9;
			b=9;
			 result= OneOrSumTen.isOneOrSum10(a, b);
			
			if(result){
				System.out.println("Pass");
			}
			else{
				System.out.println("When A is " +a+ ", when B is " +b+ " the result is " +result+ " EXPECTED IS FALSE" );
			}	
			
			
			//Case 3 when a=1 and b=9, Result must be True
			a=1;
			b=9;
			result= OneOrSumTen.isOneOrSum10(a, b);
			
			if(result){
				System.out.println("When A is " +a+ ", when B is " +b+ " the result is " +result+ " EXPECTED IS TRUE" );
			}
			else{
				System.out.println("FAIL!!");
			}
			
			//Case 4 when a=10 and b=10, Result must be Pass
			a=10;
			b=10;
			result= OneOrSumTen.isOneOrSum10(a, b);
			
			if(result){
				System.out.println("When A is " +a+ ", when B is " +b+ " the result is " +result+ " EXPECTED IS TRUE" );
			}
			else{
				System.out.println("FAIL!!");
			}	
		}
	}
	
