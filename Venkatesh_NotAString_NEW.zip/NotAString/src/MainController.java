import java.util.Scanner;

public class MainController {
	
	public static void main(String args[]){
		   String str;
		   Scanner scan=new Scanner(System.in);
		   
		   System.out.println("Enter your String");
		   str=scan.nextLine();
		   
		   String newString=NotString.notAString(str);// Calling the method
		   
		   System.out.println("The String is  " +newString);   
	   }
}
