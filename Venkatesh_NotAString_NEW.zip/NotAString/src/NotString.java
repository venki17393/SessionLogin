/*
 * Venkatesh K
 * 11-April-2017
 * notAString Challenge
 */



import java.util.*;

public class NotString {
	/**
	 *Given a string return the same string if it is starting with "not" else append "not" with the string and then return the corresponding string
	 * 
	 * @param str
	 * @return String
	 */
	
	
	public static String notAString(String str) {
		
		if(str.length() > 3) {
		String first=str.substring(0,3);
		String test = "not";
		
		
			if(first.equals(test)){
				return str;
			}
			
			else{
				str=test+" "+str;
				return str;
			}
	  }
		
			else {
				str = "not" + " " + str;
				return str;
	  }
}
	
 
	public static void main(String args[]) {
	 
	   //Initializing various test Cases
	   String case1 ="going to happen";
	   String case2 ="a";
	   String case3 ="not interested";
	   
	   // Stroring the expected Values
	   String expected1="not going to happen";
	   String expected2="not a";
	   String expected3="not interested";
	   
	   //Calling the notAString method and storing it in the result variables
	   String result1 = notAString(case1);
	   String result2 = notAString(case2);
	   String result3 = notAString(case3);
	   
	   // Case 1 Testing
	   		if(result1.equals(expected1)) {
	   			System.out.println("Pass");
	   		}
		   
		   else {
			   	System.out.println("Fail");
		   }
	   		

	   	// Case 2 Testing		
	   		if(result2.equals(expected2)) {
	   			System.out.println("Pass");
	   		}
		   
		   else {
			   	System.out.println("Fail");
		   }
	   		
	   	
	   	// Case 3 Testing
	   		if(result3.equals(expected3)) {
	   			System.out.println("Pass");
	   		}
		   
		   else {
			   	System.out.println("fail");
		   }   
}
}
